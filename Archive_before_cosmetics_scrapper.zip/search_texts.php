<?php
     $owner_fname_arr = array("owner name","first name");
     $owner_lname_arr = array("last name");
     $mailing_address_arr = array("mailing address","street","house no","house number", "unit number");
     $mailing_city_arr = array("city");
     $mailing_state_arr = array("state");
     $mailing_zip_arr = array("zip","postal code","post code");
     $bedrooms_arr = array("beds","bedrooms","no.of.beds","no of beds");
     $bathrooms_arr = array("baths","bathrooms","bathroom",);
     $owner_type_arr = array();
     $property_use_arr = array();
     $year_built_arr = array();
     $estimated_value_arr = array();
     $last_sale_date_arr = array();
     $last_sale_price_arr = array();
     $legal_description_arr = array();
     $mortgage_date_arr = array();
     $mortgage_lender_arr = array();
     $mortgage_amount_arr = array();
     $estimated_mortgage_balance_arr = array();
     $estimated_equity_usd_arr = array();
     $estimated_equity_percentage_arr = array();
     $state_arr = array();
     $latitude_arr = array();
     $longitude_arr = array();
?>