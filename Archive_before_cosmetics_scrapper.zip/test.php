<ul><li><a href="/state/FL/county/alachua">Alachua</a></li>
<li><a href="/state/FL/county/baker">Baker</a></li>
<li><a href="/state/FL/county/bay">Bay</a></li>
<li><a href="/state/FL/county/bradford">Bradford</a></li>
<li><a href="/state/FL/county/brevard">Brevard</a></li>
<li><a href="/state/FL/county/broward">Broward</a></li>
<li><a href="/state/FL/county/calhoun">Calhoun</a></li>
<li><a href="/state/FL/county/charlotte">Charlotte</a></li>
<li><a href="/state/FL/county/citrus">Citrus</a></li>
<li><a href="/state/FL/county/clay">Clay</a></li>
<li><a href="/state/FL/county/collier">Collier</a></li>
<li><a href="/state/FL/county/columbia">Columbia</a></li>
<li><a href="/state/FL/county/desoto">DeSoto</a></li>
<li><a href="/state/FL/county/dixie">Dixie</a></li>
<li><a href="/state/FL/county/duval">Duval</a></li>
<li><a href="/state/FL/county/escambia">Escambia</a></li>
<li><a href="/state/FL/county/flagler">Flagler</a></li>
</ul>