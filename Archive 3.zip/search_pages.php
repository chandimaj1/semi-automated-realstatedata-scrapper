<?php
ini_set('display_errors', 0);
ini_set('display_startup_errors', 0);

$url = $_GET['link'];
$domain = $_GET['domain'];
$confidence = $_GET['confidence'];

include('simple_html_dom.php');
require_once('search_texts.php');

// Clean passed string for search friendliness
function clean($string) {
    $string = str_replace(' ', '+', $string); // Replaces all spaces with hyphens.
 
    return preg_replace('/[^A-Za-z0-9\-]/', '', $string); // Removes special chars.
 }
 $search = clean($search);


    $curl = curl_init('http://127.0.0.1:9999');
    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    curl_setopt_array($curl,array(
        CURLOPT_USERAGENT=>'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:60.0) Gecko/20100101 Firefox/60.0',
        CURLOPT_ENCODING=>'gzip, deflate',
        CURLOPT_HTTPHEADER=>array(
                'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                'Accept-Language: en-US,en;q=0.5',
                'Connection: keep-alive',
                'Upgrade-Insecure-Requests: 1',
                'Cookie',      
        ),
    ));

    $result = curl_exec($curl);
    curl_close($curl);

    $domResult = new simple_html_dom();
    $domResult->load($result);
    

if ($domain=="redfin.com"){
    $mailing_address_find = '#overview-scroll span[data-rf-test-id=abp-streetLine]';
    $mailing_city_find = '#overview-scroll span[data-rf-test-id=abp-cityStateZip] .locality';
    $mailing_state_find = '#overview-scroll span[data-rf-test-id=abp-cityStateZip] .region';
    $mailing_zip_find = '#overview-scroll span[data-rf-test-id=abp-cityStateZip] .postal-code';
    $year_built_find = '#overview-scroll span[data-rf-test-id=abp-yearBuilt] .value';
    $estimated_value_find = '#overview-scroll div[data-rf-test-id=avm-price] .statsValue';
    $last_sale_price_find = '#overview-scroll div[data-rf-test-id=abp-price] .statsValue';
    $bedrooms_find = '#overview-scroll div[data-rf-test-id=abp-beds] .statsValue';
    $bathrooms_find = '#overview-scroll div[data-rf-test-id=abp-baths] .statsValue';

}else if($domain=='movoto.com'){
    $mailing_address_find = '#dppHeader .dpp-header-title .title';
    $estimated_value_find = '#dppHeader .dpp-price span[data-priceupdate]';
    $property_use_find = 'div[section=PublicRecord] ul li a[data-ga-name=BasicInfoPropertyType]';
}else{
    $domain = 'no_domain';
}


   

    foreach ($domResult -> find($mailing_address_find) as $x){
        $mailing_address = $x->plaintext;
    } 
    foreach ($domResult -> find($mailing_city_find) as $x){
        $mailing_city = $x->plaintext;
    } 
    foreach ($domResult -> find($mailing_state_find) as $x){
        $mailing_state = $x->plaintext;
    } 
    foreach ($domResult -> find($mailing_zip_find) as $x){
        $mailing_zip= $x->plaintext;
    } 
    foreach ($domResult -> find($year_built_find) as $x){
        $year_built= $x->plaintext;
    } 
    foreach ($domResult -> find($estimated_value_find) as $x){
        $estimated_value= $x->plaintext;
    } 
    foreach ($domResult -> find($last_sale_price_find) as $x){
        $last_sale_price= $x->plaintext;
    } 
    foreach ($domResult -> find($bedrooms_find) as $x){
        $bedrooms= $x->plaintext;
    }
    foreach ($domResult -> find($bathrooms_find) as $x){
        $bathrooms= $x->plaintext;
    }
    foreach ($domResult -> find($property_use_find) as $x){
        $property_use= $x->plaintext;
    }

    //Parsing property details scroll data
    $grab_next = false;

    //check test containing values in a string
    function strposa($haystack, $needle, $offset=0) {
    if(!is_array($needle)) $needle = array($needle);
    foreach($needle as $query) {
        if(stripos($haystack, $query, $offset) !== false) return true; // stop on first true result
    }
    return false;
}
    

 switch ($domain){   

    case 'redfin.com':{
        //Legal Desc, Property use
        foreach ($domResult -> find('#property-details-scroll .amenities-container .entryItemContent text') as $x){
            $x = $x->plaintext;
            //Executed 2nd based on grab_next
            if($grab_next=='legal_description'){$legal_description = $x; $grab_next = false; continue;}
            else if($grab_next == "property_use"){ $property_use = $x; $grab_next = false; continue;}
            //Executed 1st and set grab_next
            if (strpos($x, 'Legal Description:') !== false) {$grab_next = "legal_description";}
            else if(strpos($x, 'State Use Description') !== false){$grab_next = "property_use";}
        }
        break;
    }

    case 'movoto.com':{

        // City & State
        $x = $domResult -> find('#dppHeader .dpp-header-title a.text-gray',0);
        $x = $x->plaintext;
        $arr = explode(",",$x,2);
        $mailing_city = $arr[0];
        $mailing_state = $arr[1];
        //Zip
        $x = $domResult -> find('#dppHeader .dpp-header-title a.text-gray',1);
        $mailing_zip= $x->plaintext;

        //Beds, Baths, Last Sale Price, Last Sale Date, Year Built
        foreach ($domResult -> find('.dpp-column[section=PublicRecord] ul li text') as $x){
            $x = $x->plaintext;

            // Executed 2nd checking grab_next value
            if($grab_next=="bathrooms"){$bathrooms = $x; $grab_next = false; continue;}
            else if($grab_next == "bedrooms"){ $bedrooms = $x; $grab_next = false; continue;}
            else if($grab_next == "last_sale_price"){ $last_sale_price = $x; $grab_next = false; continue;}
            else if($grab_next == "year_built"){ $year_built = $x; $grab_next = false; continue;}
            else if($grab_next == "last_sale_date"){ $last_sale_date = $x; $grab_next = false; continue;}

            // Executed first
            if (strpos($x, 'Baths') !== false) {$grab_next = "bathrooms";}
            else if(strpos($x, 'Beds') !== false){$grab_next = "bedrooms";}
            else if(strpos($x, 'Last Sale Price') !== false){$grab_next = "last_sale_price";}
            else if(strpos($x, 'Year Built') !== false){$grab_next = "year_built";}
            else if(strpos($x, 'Last Sale Date') !== false){$grab_next = "last_sale_date";}
        }

        
        break;
    }

/*
    default:{

        foreach ($domResult -> find('body text') as $x){
            $x = $x->plaintext;
 

            // Executed 2nd checking grab_next value
            
            if($grab_next=="owner_fname"){$owner_fname = $x; $grab_next = false;}
            else if($grab_next == "owner_lname"){ $owner_lname = $x; $grab_next = false;}
            else if($grab_next == "mailing_address"){ $mailing_address = $x; $grab_next = false;}
            else if($grab_next == "mailing_city"){ $mailing_city = $x; $grab_next = false; }
            else if($grab_next == "mailing_state"){ $mailing_state = $x; $grab_next = false; continue;}
            else if($grab_next == "mailing_zip"){ $mailing_zip = $x; $grab_next = false; continue;}
            else if($grab_next == "bedrooms"){ $bedrooms = $x; $grab_next = false; continue;}
            else if($grab_next == "bathrooms"){ $bathrooms = $x; $grab_next = false; continue;}
            else if($grab_next == "owner_type"){ $owner_type = $x; $grab_next = false; continue;}
            else if($grab_next == "property_use"){ $property_use = $x; $grab_next = false; continue;}
            else if($grab_next == "year_built"){ $year_built = $x; $grab_next = false; continue;}
            else if($grab_next == "estimated_value"){ $estimated_value = $x; $grab_next = false; continue;}
            else if($grab_next == "last_sale_date"){ $last_sale_date = $x; $grab_next = false; continue;}
            else if($grab_next == "last_sale_price"){ $last_sale_price = $x; $grab_next = false; continue;}
            else if($grab_next == "legal_description"){ $legal_description = $x; $grab_next = false; continue;}
            else if($grab_next == "mortgage_date"){ $mortgage_date = $x; $grab_next = false; continue;}
            else if($grab_next == "mortgage_lender"){ $mortgage_lender = $x; $grab_next = false; continue;}
            else if($grab_next == "mortgage_amount"){ $mortgage_amount = $x; $grab_next = false; continue;}
            else if($grab_next == "estimated_mortgage_balance"){ $estimated_mortgage_balance = $x; $grab_next = false; continue;}
            else if($grab_next == "estimated_equity_usd"){ $estimated_equity_usd = $x; $grab_next = false; continue;}
            else if($grab_next == "estimated_equity_percentage"){ $estimated_equity_percentage = $x; $grab_next = false; continue;}
            else if($grab_next == "latitude"){ $latitude = $x; $grab_next = false; continue;}
            else if($grab_next == "longitude"){ $longitude = $x; $grab_next = false; continue;}

            // Executed first
            // Add search texts from search_texts.php
            if (strposa($x, $owner_fname_arr)) {$grab_next = "owner_fname";}
            else if(strposa($x, $owner_lname_arr)){$grab_next = "owner_lname";}
            else if(strposa($x, $mailing_address_arr) !== false){$grab_next = "mailing_address";}
            else if(strposa($x, $mailing_city_arr) !== false){$grab_next = "mailing_city";}
            else if(strposa($x, $mailing_state_arr) !== false){$grab_next = "mailing_state";}
            else if(strposa($x, $mailing_zip_arr) !== false){$grab_next = "mailing_zip";}
            else if(strposa($x, $bedrooms_arr) !== false){$grab_next = "bedrooms";}
            else if(strposa($x, $bathrooms_arr) !== false){$grab_next = "bathrooms";}
            else if(strposa($x, $owner_type_arr) !== false){$grab_next = "owner_type";}
            else if(strposa($x, $property_use_arr) !== false){$grab_next = "property_use";}
            else if(strposa($x, $year_built_arr) !== false){$grab_next = "year_built";}
            else if(strposa($x, $estimated_value_arr) !== false){$grab_next = "estimated_value";}
            else if(strposa($x, $last_sale_date_arr) !== false){$grab_next = "last_sale_date";}
            else if(strposa($x, $last_sale_price_arr) !== false){$grab_next = "last_sale_price";}
            else if(strposa($x, $legal_description_arr) !== false){$grab_next = "legal_description";}
            else if(strposa($x, $mortgage_date_arr) !== false){$grab_next = "mortgage_date";}
            else if(strposa($x, $mortgage_lender_arr) !== false){$grab_next = "mortgage_lender";}
            else if(strposa($x, $mortgage_amount_arr) !== false){$grab_next = "mortgage_amount";}
            else if(strposa($x, $estimated_mortgage_balance_arr) !== false){$grab_next = "estimated_mortgage_balance";}
            else if(strposa($x, $estimated_equity_usd_arr) !== false){$grab_next = "estimated_equity_usd";}
            else if(strposa($x, $estimated_equity_percentage_arr) !== false){$grab_next = "estimated_equity_percentage";}
            else if(strposa($x, $latitude_arr) !== false){$grab_next = "latitude";}
            else if(strposa($x, $longitude_arr) !== false){$grab_next = "longitude";}
            
        }
        break;
    }
    */
    
}

    $send = array(
        'owner_fname'=>"$owner_fname",
        'owner_lname'=>"$owner_lname",
        'mailing_address'=>"$mailing_address",
        'mailing_city'=>"$mailing_city",
        'mailing_state'=>"$mailing_state",
        'mailing_zip'=>"$mailing_zip",
        'bedrooms'=>"$bedrooms",
        'bathrooms'=>"$bathrooms",
        'owner_type'=>"$owner_type", 
        'property_use'=>"$property_use",
        'year_built'=>"$year_built",
        'estimated_value'=>"$estimated_value",
        'last_sale_date'=>"$last_sale_date",
        'last_sale_price'=>"$last_sale_price",
        'legal_description'=>"$legal_description",
        'mortgage_date'=>"$mortgage_date",
        'mortgage_lender'=>"$mortgage_lender",
        'mortgage_amount'=>"$mortgage_amount",
        'estimated_mortgage_balance'=>"$estimated_mortgage_balance",
        'estimated_equity_usd'=>"$estimated_equity_usd",
        'estimated_equity_percentage'=>"$estimated_equity_percentage",
        'latitude'=>"$latitude",
        'longitude'=>"$longitude"
    );
/*
    foreach ($send as $key=>$val){
        echo($key.'='.$val.'<br>');
    }
*/

   // echo($domResult);

   $send = json_encode($send);
   echo($send);

?>