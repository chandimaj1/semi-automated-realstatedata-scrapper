<?php

$url = $_POST['link'];
$domain = $_POST['domain'];
$title = $_POST['title'];
$weight = int($_POST['weight']);

$url = "https://clustrmaps.com/a/1i3hmr/";
$domain = "clustrmaps.com";

//$url = "";

include('simple_html_dom.php');

// Clean passed string for search friendliness
function clean($string) {
    $string = str_replace(' ', '+', $string); // Replaces all spaces with hyphens.
 
    return preg_replace('/[^A-Za-z0-9\-]/', '', $string); // Removes special chars.
 }
 $search = clean($search);


    $curl = curl_init('http://127.0.0.1:9999');
    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    curl_setopt_array($curl,array(
        CURLOPT_USERAGENT=>'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:60.0) Gecko/20100101 Firefox/60.0',
        CURLOPT_ENCODING=>'gzip, deflate',
        CURLOPT_HTTPHEADER=>array(
                'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                'Accept-Language: en-US,en;q=0.5',
                'Connection: keep-alive',
                'Upgrade-Insecure-Requests: 1',
                'Cookie',      
        ),
    ));

    $result = curl_exec($curl);
    curl_close($curl);

    $domResult = new simple_html_dom();
    $domResult->load($result);


    echo($domain.'<br>');
    

if ($domain=="redfin.com"){
    $mailing_address_find = '#overview-scroll span[data-rf-test-id=abp-streetLine]';
    $mailing_city_find = '#overview-scroll span[data-rf-test-id=abp-cityStateZip] .locality';
    $mailing_state_find = '#overview-scroll span[data-rf-test-id=abp-cityStateZip] .region';
    $mailing_zip_find = '#overview-scroll span[data-rf-test-id=abp-cityStateZip] .postal-code';
    $year_built_find = '#overview-scroll span[data-rf-test-id=abp-yearBuilt] .value';
    $estimated_value_find = '#overview-scroll div[data-rf-test-id=avm-price] .statsValue';
    $last_sale_price_find = '#overview-scroll div[data-rf-test-id=abp-price] .statsValue';
    $bedrooms_find = '#overview-scroll div[data-rf-test-id=abp-beds] .statsValue';
    $bathrooms_find = '#overview-scroll div[data-rf-test-id=abp-baths] .statsValue';

}else if($domain=='movoto.com'){
    $mailing_address_find = '#dppHeader .dpp-header-title .title';
    $estimated_value_find = '#dppHeader .dpp-price span[data-priceupdate]';
    $property_use_find = 'div[section=PublicRecord] ul li a[data-ga-name=BasicInfoPropertyType]';
}else{
    echo("unknown domain");
}


   

    foreach ($domResult -> find($mailing_address_find) as $x){
        $mailing_address = $x->plaintext;
    } 
    foreach ($domResult -> find($mailing_city_find) as $x){
        $mailing_city = $x->plaintext;
    } 
    foreach ($domResult -> find($mailing_state_find) as $x){
        $mailing_state = $x->plaintext;
    } 
    foreach ($domResult -> find($mailing_zip_find) as $x){
        $mailing_zip= $x->plaintext;
    } 
    foreach ($domResult -> find($year_built_find) as $x){
        $year_built= $x->plaintext;
    } 
    foreach ($domResult -> find($estimated_value_find) as $x){
        $estimated_value= $x->plaintext;
    } 
    foreach ($domResult -> find($last_sale_price_find) as $x){
        $last_sale_price= $x->plaintext;
    } 
    foreach ($domResult -> find($bedrooms_find) as $x){
        $bedrooms= $x->plaintext;
    }
    foreach ($domResult -> find($bathrooms_find) as $x){
        $bathrooms= $x->plaintext;
    }
    foreach ($domResult -> find($property_use_find) as $x){
        $property_use= $x->plaintext;
    }

    //Parsing property details scroll data
    $grab_next = false;

 switch ($domain){   

    case 'redfin.com':{
        //Legal Desc, Property use
        foreach ($domResult -> find('#property-details-scroll .amenities-container .entryItemContent text') as $x){
            $x = $x->plaintext;
            //Executed 2nd based on grab_next
            if($grab_next=='legal_description'){$legal_description = $x; $grab_next = false; continue;}
            else if($grab_next == "property_use"){ $property_use = $x; $grab_next = false; continue;}
            //Executed 1st and set grab_next
            if (strpos($x, 'Legal Description:') !== false) {$grab_next = "legal_description";}
            else if(strpos($x, 'State Use Description') !== false){$grab_next = "property_use";}
        }
        break;
    }

    case 'movoto.com':{

        // City & State
        $x = $domResult -> find('#dppHeader .dpp-header-title a.text-gray',0);
        $x = $x->plaintext;
        $arr = explode(",",$x,2);
        $mailing_city = $arr[0];
        $mailing_state = $arr[1];
        //Zip
        $x = $domResult -> find('#dppHeader .dpp-header-title a.text-gray',1);
        $mailing_zip= $x->plaintext;

        //Beds, Baths, Last Sale Price, Last Sale Date, Year Built
        foreach ($domResult -> find('.dpp-column[section=PublicRecord] ul li text') as $x){
            $x = $x->plaintext;

            // Executed 2nd checking grab_next value
            if($grab_next=="bathrooms"){$bathrooms = $x; $grab_next = false; continue;}
            else if($grab_next == "bedrooms"){ $bedrooms = $x; $grab_next = false; continue;}
            else if($grab_next == "last_sale_price"){ $last_sale_price = $x; $grab_next = false; continue;}
            else if($grab_next == "year_built"){ $year_built = $x; $grab_next = false; continue;}
            else if($grab_next == "last_sale_date"){ $last_sale_date = $x; $grab_next = false; continue;}

            // Executed first
            if (strpos($x, 'Baths') !== false) {$grab_next = "bathrooms";}
            else if(strpos($x, 'Beds') !== false){$grab_next = "bedrooms";}
            else if(strpos($x, 'Last Sale Price') !== false){$grab_next = "last_sale_price";}
            else if(strpos($x, 'Year Built') !== false){$grab_next = "year_built";}
            else if(strpos($x, 'Last Sale Date') !== false){$grab_next = "last_sale_date";}
        }

        
        break;
    }
    
}

    // Format data for each search
    /*
    foreach($domResult->find('a[href^=/url?]') as $link){
        $title = trim($link->plaintext);
        $arr = explode("|", str_replace(array("-"),"|",$title),2);
        $title = $arr[0];
        $link  = trim($link->href);

        if (!preg_match('/^https?/', $link) && preg_match('/q=(.+)&amp;sa=/U', $link, $matches) && preg_match('/^https?/', $matches[1])) {
            $link = $matches[1];
        } else if (!preg_match('/^https?/', $link)) { // skip if it is not a valid link
            //continue;    
        }
        
    }
    */


    $send = array(
        'owner_fname'=>"",
        'owner_lname'=>"",
        'mailing_address'=>"$mailing_address",
        'mailing_city'=>"$mailing_city",
        'mailing_state'=>"$mailing_state",
        'mailing_zip'=>"$mailing_zip",
        'bedrooms'=>"$bedrooms",
        'bathrooms'=>"$bathrooms",
        'owner_type'=>"", 
        'property_use'=>"$property_use",
        'year_built'=>"$year_built",
        'estimated_value'=>"$estimated_value",
        'last_sale_date'=>"",
        'last_sale_price'=>"$last_sale_price",
        'legal_description'=>"$legal_description",
        'mortgage_date'=>"",
        'mortgage_lender'=>"",
        'mortgage_amount'=>"",
        'estimated_mortgage_balance'=>"",
        'estimated_equity_usd'=>"",
        'estimated_equity_percentage'=>"",
        'latitude'=>"",
        'longitude'=>"",
        'weight'=>"$weight",
        'message'=>""
    );

    foreach ($send as $key=>$val){
        echo($key.'='.$val.'<br>');
    }

    echo($domResult);

?>